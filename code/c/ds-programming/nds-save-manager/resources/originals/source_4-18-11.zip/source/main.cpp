/**
 * NDS Save Manager, v.0.0.4
 *     written by Akoi Meexx
 * 
 * http://akoimeexx.com/projects/
 */

// Include standard header files from devkitARM
#include <nds.h>

// Include main structures
#include "main.h"

// Include Screen headers
#include "screen_mainmenu.h"
#include "screen_backupmenu.h"
#include "screen_restoremenu.h"
#include "screen_terminal.h"


int main(void) {
	int APPLICATION_STATE = STARTUP;
	
	// Old ApplicationState handler
	bool t_init = false;
	
	while(APPLICATION_STATE != SHUTDOWN) {
		if (APPLICATION_STATE == STARTUP) {
			APPLICATION_STATE = mainmenuInit();
		}
		if (APPLICATION_STATE == BACKUPMENU) {
			APPLICATION_STATE = backupmenuInit();
		}
		if (APPLICATION_STATE == RESTOREMENU) {
			APPLICATION_STATE = restoremenuInit();
		}
		//terminalInit();
		//t_init = true;
		//APPLICATION_STATE = DEBUGGING;

		
		swiWaitForVBlank();
		scanKeys();
		if (keysDown() && t_init == true) {
			if (keysDown()&KEY_A) terminalPrint("(A) button pressed");
			if (keysDown()&KEY_B) terminalPrint("(B) button pressed");
			if (keysDown()&KEY_X) terminalPrint("(X) button pressed");
			if (keysDown()&KEY_Y) terminalPrint("(Y) button pressed");
			if (keysDown()&KEY_L) terminalPrint("(L) button pressed");
			if (keysDown()&KEY_R) terminalPrint("(R) button pressed");
			if (keysDown()&KEY_UP) terminalPrint("(UP) button pressed");
			if (keysDown()&KEY_DOWN) terminalPrint("(DOWN) button pressed");
			if (keysDown()&KEY_LEFT) terminalPrint("(LEFT) button pressed");
			if (keysDown()&KEY_RIGHT) terminalPrint("(RIGHT) button pressed");
			if (keysDown()&KEY_START) APPLICATION_STATE = STARTUP;
			if (keysDown()&KEY_L && keysDown()&KEY_R) terminalClear();
		}
		if (keysDown()&KEY_SELECT) {
			APPLICATION_STATE = SHUTDOWN;
		}
	}
}
