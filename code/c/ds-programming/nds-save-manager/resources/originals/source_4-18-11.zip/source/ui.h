typedef struct {
	int x1;
	int y1;
	int x2;
	int y2;
}UIArea;

typedef struct {
	int width;
	int height;
	int x;
	int y;
	UIArea region;
}UIRegion;

UIRegion UIbutton(int width, int height, int x, int y);
