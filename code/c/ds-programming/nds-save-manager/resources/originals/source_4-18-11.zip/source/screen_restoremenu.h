int restoremenuInit(void);

