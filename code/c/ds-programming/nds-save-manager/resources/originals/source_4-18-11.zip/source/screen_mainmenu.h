int mainmenuInit(void);

