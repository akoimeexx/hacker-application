// Define Application States
enum CODE_STATE {
	SHUTDOWN = -1, 
	STARTUP = 0, 
	MAINMENU = 1, 
	BACKUPMENU = 2, 
	RESTOREMENU = 3, 
	DELETEMENU = 4, 
	LOADINGMEDIA = 5, 
	TRANSFERDIALOG = 6, 
	COMPLETEDTRANSFER = 7, 
	
	/* Remove this STATE when finished */
	DEBUGGING = 42
};

// Define test string constant, 256 characters in length
const char TEST_STRING[256] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\n1234567890-=~!@#$%%^&*()_+[]{}\\|;':\",.<>/?\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas tincidunt consequat sem eu sagittis. Aenean felis mauris, imperdiet nec dictum cras amet.";
// Define credits string constant
const char CREDITS[203] = "NDS Save Manager v0.0.4\n  written by Akoi Meexx\n\nSpecial thanks to mtheall, zeromus, and everyone at irc.blitzed.org/#dsdev; as well as pokedoc for inspiring me to write my own version of his program.";


int main(void);
