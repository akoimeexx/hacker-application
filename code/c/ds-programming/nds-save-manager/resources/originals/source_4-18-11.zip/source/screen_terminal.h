#include <nds/arm9/console.h>

extern PrintConsole terminal;

void terminalInit(void);

void terminalPrint(const char message[768]);
void terminalClear(void);
