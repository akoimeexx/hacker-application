#include <nds.h>
#include <stdio.h>

// Include terminal
#include "screen_terminal.h"
PrintConsole terminal;

// Include Main Screen Terminal Graphic
#include "screenimage-terminal.h"

void terminalInit(void)
{
	videoSetMode(MODE_3_2D);
	int bg = bgInit(3, BgType_Bmp8, BgSize_B8_256x256, 1,0);
	decompress(screenimage_terminalBitmap, bgGetGfxPtr(bg),  LZ77Vram);
	
	consoleInit(&terminal, 0, BgType_Text4bpp, BgSize_T_256x256, 2, 0, true, true);
	
	dmaCopy(screenimage_terminalPal, BG_PALETTE, screenimage_terminalPalLen);
	BG_PALETTE[255] = RGB15(31,31,31);
	
	consoleSetWindow(&terminal, 3, 3, 26, 15);
	consoleClear();
	terminalPrint("Terminal initialized...");
}

void terminalPrint(const char message[768])
{
	consoleSelect(&terminal);
	iprintf("%s\n", message);
}

void terminalClear(void)
{
	consoleSelect(&terminal);
	consoleClear();
}
