int backupmenuInit(void);

