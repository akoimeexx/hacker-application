#include <nds.h>

// Include main structures
#include "main.h"

// Include screen_mainmenu structures
#include "screen_restoremenu.h"

// Include images
#include "screenimage-logo.h"
#include "screenimage-restoremenu.h"

// Include UI functions
#include "ui.h"


int restoremenuInit(void)
{
	// Set video mode on both screens to two text/extended bg layers
 	videoSetMode(MODE_3_2D);
	videoSetModeSub(MODE_3_2D);
	
	// Assign memory banks
	vramSetBankA(VRAM_A_MAIN_BG);
	vramSetBankC(VRAM_C_SUB_BG);
	
	// Initialize background instances
	int bg = bgInit(3, BgType_Bmp8, BgSize_B8_256x256, 0,0);
	int bgSub = bgInitSub(3, BgType_Bmp8, BgSize_B8_256x256, 0,0);
	
	// Load logo screenimage
	decompress(screenimage_logoBitmap, bgGetGfxPtr(bg),  LZ77Vram);
	dmaCopy(screenimage_logoPal, BG_PALETTE, screenimage_logoPalLen);
	
	// Load restoremenu screenimage
	decompress(screenimage_restoremenuBitmap, bgGetGfxPtr(bgSub), LZ77Vram);
	dmaCopy(screenimage_restoremenuPal, BG_PALETTE_SUB, screenimage_restoremenuPalLen);
	
	// Load TouchPosition data
	touchPosition touch;
	
	// Create button regions for mainmenu
	//UIRegion button_backup = UIbutton(224, 48, 16, 16);
	//UIRegion button_restore = UIbutton(224, 48, 16, 72);
	
	while(1) {
		swiWaitForVBlank();
		
		// read the touchscreen coordinates
		scanKeys();
		touchRead(&touch);
				
		// if (B) Button is pressed, go back to main menu
		if (keysDown()&KEY_B) return STARTUP;
		
		if (keysDown()&KEY_SELECT) return SHUTDOWN;
	}
}
