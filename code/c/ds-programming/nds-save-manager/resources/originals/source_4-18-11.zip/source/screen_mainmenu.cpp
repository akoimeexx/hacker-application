#include <nds.h>

// Include main structures
#include "main.h"
// Include screen_mainmenu structures
#include "screen_mainmenu.h"

// Include images
#include "screenimage-logo.h"
#include "screenimage-mainmenu.h"

// Include UI functions
#include "ui.h"


int mainmenuInit(void)
{
	// Set video mode on both screens to two text/extended bg layers
 	videoSetMode(MODE_3_2D);
	videoSetModeSub(MODE_3_2D);
	
	// Assign memory banks
	vramSetBankA(VRAM_A_MAIN_BG);
	vramSetBankC(VRAM_C_SUB_BG);
	
	// Initialize background instances
	int bg = bgInit(3, BgType_Bmp8, BgSize_B8_256x256, 0,0);
	int bgSub = bgInitSub(3, BgType_Bmp8, BgSize_B8_256x256, 0,0);
	
	// Load logo screenimage
	decompress(screenimage_logoBitmap, bgGetGfxPtr(bg),  LZ77Vram);
	dmaCopy(screenimage_logoPal, BG_PALETTE, screenimage_logoPalLen);
	
	// Load mainmenu screenimage
	decompress(screenimage_mainmenuBitmap, bgGetGfxPtr(bgSub), LZ77Vram);
	dmaCopy(screenimage_mainmenuPal, BG_PALETTE_SUB, screenimage_mainmenuPalLen);
	
	// Load TouchPosition data
	touchPosition touch;
	
	// Create button regions for mainmenu
	UIRegion button_backup = UIbutton(224, 48, 16, 16);
	UIRegion button_restore = UIbutton(224, 48, 16, 72);
	UIRegion button_delete = UIbutton(224, 48, 16, 128);
	
	while(1) {
		swiWaitForVBlank();
		
		// read the touchscreen coordinates
		scanKeys();
		touchRead(&touch);
		
		// if button_backup region touched...
		if (touch.px >= button_backup.region.x1 && touch.px <= button_backup.region.x2 && touch.py >= button_backup.region.y1 && touch.py <= button_backup.region.y2) {
			return BACKUPMENU;
		}
		// if button_restore region touched...
		if (touch.px >= button_restore.region.x1 && touch.px <= button_restore.region.x2 && touch.py >= button_restore.region.y1 && touch.py <= button_restore.region.y2) {
			return RESTOREMENU;
		}
		// if button_delete region touched...
		if (touch.px >= button_delete.region.x1 && touch.px <= button_delete.region.x2 && touch.py >= button_delete.region.y1 && touch.py <= button_delete.region.y2) {
			return DELETEMENU;
		}
		
		if (keysDown()&KEY_SELECT) return SHUTDOWN;
	}
}
