#include <nds.h>
#include <maxmod9.h>
#include "soundbank.h"
#include "soundbank_bin.h"

void sfxInit(void)
{
	mmInitDefaultMem((mm_addr)soundbank_bin);
	mmLoadEffect( SFX_CHORD );
	
	mm_sound_effect chord = {
		{ SFX_CHORD }, // id
		(int)(1.0f * (1<<10)), // rate
		0, // handle
		255, // volume
		0, // panning
	};
}

void sfxStartup(void)
{
	// Play startup chord
	mmEffectEx(&chord);
}
