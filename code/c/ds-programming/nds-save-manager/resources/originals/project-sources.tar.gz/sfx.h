void sfxInit(void);
void sfxStartup(void);
